// export default function Page() {
//     return (
//         <div>new rider form</div>
//     );
// }// app/admin/(protected)/deliveries/new/page.jsx
"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

// Only one client exists right now (seeded by seed.js). Swap this for
// a client picker once a second business is actually onboarded.
const CORN_MART_CLIENT_NAME = "Corn Mart";

const initialForm = {
  name: "",
  phone: "",
  vehicle_type: "",
  license_no: "",
  status: "available",
  rating: 0,
  email: "",
  password: "",
  //   delivery_fee: '',
};

function Field({ label, children }) {
  return (
    <label className="block mb-4">
      <span className="block text-sm font-medium text-[#262620] mb-1">
        {label}
      </span>
      {children}
    </label>
  );
}

const inputClass =
  "w-full px-3 py-2 border border-[#E5E1D8] rounded-md text-sm bg-white " +
  "focus:outline-none focus:ring-2 focus:ring-[#D4A017]/40 focus:border-[#D4A017]";

export default function NewRiderPage() {
  const router = useRouter();
  const supabase = createClient();

  const [form, setForm] = useState(initialForm);
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  function update(field, value) {
    setForm((f) => ({ ...f, [field]: value }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");
    setSubmitting(true);

    // const { data: client, error: clientError } = await supabase
    //   .from('clients')
    //   .select('id')
    //   .eq('name', CORN_MART_CLIENT_NAME)
    //   .single()

    // if (clientError || !client) {
    //   setError(
    //     'Could not find the Corn Mart client record — has seed.js been run?'
    //   )
    //   setSubmitting(false)
    //   return
    // }
    const { data, error } = await supabase.auth.signUp({
      email: form.email,
      password : form.email,
      options: {
        data: {
          full_name: form.name,
          phone: form.phone,
        },
      },
    });

    if (error) {
      setError(error.message);
      return { error: error.message };
    }

    if (data?.user) {
      const encodedName = encodeURIComponent(form.name);
      const avatarUrl = `https://api.dicebear.com/9.x/initials/svg?seed=${encodedName}&backgroundColor=c5c5c5&textColor=ffffff`;

      const { data: rider, error: riderError } = await supabase
        .from("riders")
        .insert({
          id: data.user.id,
          name: form.name,
          phone: form.phone,
          vehicle_type: form.vehicle_type,
          license_no: form.license_no,
          status: form.status,
          rating: form.rating,
          avatar_url: avatarUrl,
        })
        .select("id")
        .single();

      if (riderError) {
        setError(riderError.message);
        setSubmitting(false);
        return;
      }
    }

    // const { error: parcelError } = await supabase.from("parcels").insert({
    //   delivery_order_id: order.id,
    //   description: form.parcel_description,
    //   weight_kg: form.parcel_weight_kg ? Number(form.parcel_weight_kg) : null,
    //   fragile: form.fragile,
    // });

    setSubmitting(false);

    // if (parcelError) {
    //   // The order exists but the parcel didn't save — surface this clearly
    //   // rather than silently losing the parcel details.
    //   setError(
    //     `Delivery was created, but the parcel details failed to save: ${parcelError.message}`
    //   );
    //   return;
    // }

    router.push("/admin/riders");
    router.refresh();
  }

  return (
    <div className="max-w-2xl">
      <div className="mb-6">
        <Link
          href="/admin/riders"
          className="text-sm text-[#6B6A61] hover:text-[#1E231C]"
        >
          ← Back to riders
        </Link>
        <h2 className="text-lg font-semibold text-[#262620] mt-2">New rider</h2>
        <p className="text-sm text-[#6B6A61]">Manually create a rider.</p>
      </div>

      <form
        onSubmit={handleSubmit}
        className="bg-white border border-[#E5E1D8] rounded-lg p-6"
      >
        <h3 className="text-sm font-semibold text-[#262620] mb-3">
          Rider Details
        </h3>
        <Field label="Full name">
          <input
            required
            className={inputClass}
            value={form.name}
            onChange={(e) => update("name", e.target.value)}
          />
        </Field>
        <Field label="Phone">
          <input
            required
            type="tel"
            placeholder="+2609XXXXXXXX"
            className={inputClass}
            value={form.phone}
            onChange={(e) => update("phone", e.target.value)}
          />
        </Field>
        <Field label="Email">
          <input
            required
            className={inputClass}
            value={form.email}
            onChange={(e) => update("email", e.target.value)}
          />
        </Field>

        <Field label="Password">
          <input
            required
            type="password"
            className={inputClass}
            value={form.password}
            onChange={(e) => update("password", e.target.value)}
          />
        </Field>
        <Field label="Vehicle type">
          <input
            required
            className={inputClass}
            value={form.vehicle_type}
            onChange={(e) => update("vehicle_type", e.target.value)}
          />
        </Field>

        <Field label="License number">
          <input
            required
            className={inputClass}
            value={form.license_no}
            onChange={(e) => update("license_no", e.target.value)}
          />
        </Field>
        {/* <Field label="Buyer phone">
          <input
            required
            type="tel"
            placeholder="+2609XXXXXXXX"
            className={inputClass}
            value={form.dropoff_phone}
            onChange={(e) => update("dropoff_phone", e.target.value)}
          />
        </Field>
        <Field label="Dropoff address">
          <input
            required
            className={inputClass}
            value={form.dropoff_address}
            onChange={(e) => update("dropoff_address", e.target.value)}
          />
        </Field>

        <hr className="my-5 border-[#EFECE4]" />

        <h3 className="text-sm font-semibold text-[#262620] mb-3">Parcel</h3>
        <Field label="Description">
          <input
            required
            placeholder="e.g. 10kg bag of mealie meal"
            className={inputClass}
            value={form.parcel_description}
            onChange={(e) => update("parcel_description", e.target.value)}
          />
        </Field>
        <div className="grid grid-cols-2 gap-4">
          <Field label="Weight (kg)">
            <input
              type="number"
              step="0.1"
              min="0"
              className={inputClass}
              value={form.parcel_weight_kg}
              onChange={(e) => update("parcel_weight_kg", e.target.value)}
            />
          </Field>
          <Field label="Delivery fee (K)">
            <input
              type="number"
              step="0.01"
              min="0"
              placeholder="Optional"
              className={inputClass}
              value={form.delivery_fee}
              onChange={(e) => update("delivery_fee", e.target.value)}
            />
          </Field>
        </div>
        <label className="flex items-center gap-2 mb-2 text-sm text-[#262620]">
          <input
            type="checkbox"
            checked={form.fragile}
            onChange={(e) => update("fragile", e.target.checked)}
            className="accent-[#D4A017]"
          />
          Fragile
        </label> */}

        {error && (
          <p className="text-sm text-red-600 mt-4" role="alert">
            {error}
          </p>
        )}

        <div className="flex items-center gap-3 mt-6">
          <button
            type="submit"
            disabled={submitting}
            className="bg-[#1E231C] text-white text-sm px-5 py-2 rounded-md hover:bg-[#D4A017] hover:text-[#1E231C] transition-colors disabled:opacity-50"
          >
            {submitting ? "Creating..." : "Create rider"}
          </button>
          <Link
            href="/admin"
            className="text-sm text-[#6B6A61] hover:text-[#1E231C]"
          >
            Cancel
          </Link>
        </div>
      </form>
    </div>
  );
}
