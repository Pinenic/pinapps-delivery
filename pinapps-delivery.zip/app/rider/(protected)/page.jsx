// app/rider/(protected)/page.jsx — Home: KPIs + current active jobs
import RiderHomeView from '@/components/RiderHomeView'

export const metadata = {
  title: 'Home',
}

export default function RiderHomePage() {
  return <RiderHomeView />
}